/*
 * Software License Agreement (Modified BSD License)
 *
 *  Copyright (c) 2016, PAL Robotics, S.L.
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   * Neither the name of PAL Robotics, S.L. nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 */

/** \author Jordi Pages. */

// ROS headers
#include <pcl_ros/point_cloud.h>

// PCL headers
#include <pcl/point_types.h>
#include <pcl/ModelCoefficients.h>
#pragma GCC diagnostic ignored "-Woverloaded-virtual"
#include <pcl/ModelCoefficients.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/filters/passthrough.h>
#include <pcl/filters/radius_outlier_removal.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/filters/project_inliers.h>
#include <pcl/features/normal_3d.h>
#include <pcl/search/kdtree.h>
#pragma GCC diagnostic warning "-Woverloaded-virtual"

namespace pal {

    /**
     * @brief downSample
     * @param inputCloud
     * @param outputCloud
     * @param leafSize
     */
    template <typename PointT>
    void downSample(const typename pcl::PointCloud<PointT>::Ptr& inputCloud,
                    typename pcl::PointCloud<PointT>::Ptr& outputCloud,
                    double leafSize = 0.01);

    /**
     * @brief passThrough
     * @param inputCloud
     * @param axisName
     * @param limitMin
     * @param limitMax
     * @param outputCloud
     */
    template <typename PointT>
    void passThrough(const typename pcl::PointCloud<PointT>::Ptr& inputCloud,
                     const std::string& axisName,
                     double limitMin,
                     double limitMax,
                     typename pcl::PointCloud<PointT>::Ptr& outputCloud);

    template <typename PointT>
    void downSample(const typename pcl::PointCloud<PointT>::Ptr &inputCloud,
                    typename pcl::PointCloud<PointT>::Ptr &outputCloud,
                    double leafSize);

    /**
     * @brief minNeighborsInRadiusFilter applies the pcl::RadiusOutlierRemoval filter to the given cloud
     * @param inputCloud
     * @param radius
     * @param minNeighbors
     * @param outputCloud
     */
    template <typename PointT>
    void minNeighborsInRadiusFilter(const typename pcl::PointCloud<PointT>::Ptr& inputCloud,
                                    double radius,
                                    int minNeighbors,
                                    typename pcl::PointCloud<PointT>::Ptr& outputCloud);

    /**
     * @brief statisticalOutlierRemoval applies the pcl::StatisticalOutlierRemoval filter to the given cloud
     * @param inputCloud
     * @param numberOfPoints
     * @param stdDevMult
     * @param outputCloud
     */
    template <typename PointT>
    void statisticalOutlierRemoval(const typename pcl::PointCloud<PointT>::Ptr& inputCloud,
                                   int numberOfPoints,
                                   double stdDevMult,
                                   typename pcl::PointCloud<PointT>::Ptr& outputCloud);


    /**
     * @brief extractIndices provides a new point cloud taking the points from the inputCloud specified
     *        by the given indices (setNegative == false) or those which are not in the indices
     *        (setNegative == true).
     * @param inputCloud
     * @param indices
     * @param setNegative
     * @param filteredCloud
     */
    template <typename PointT>
    void extractIndices(const typename pcl::PointCloud<PointT>::Ptr& inputCloud,
                        const typename pcl::PointIndices::Ptr& indices,
                        bool setNegative,
                        typename pcl::PointCloud<PointT>::Ptr& filteredCloud);

    /**
     * @brief planeSegmentation given a point cloud locates the main plane and returns the point
     *        cloud of this main plane and its coefficients (A·X + B·Y + C·Z + D = 0).
     * @param inputCloud
     * @param planeCloud optional. Pointer to point cloud to store the points belonging to the plane
     * @param nonPlaneCloud optional. Pointer to point cloud to store those points not belonging to the plane
     * @param coefficients optional. Pointer to object to store plane coefficients
     * @return
     */
    template <typename PointT>
    bool planeSegmentation(const typename pcl::PointCloud<PointT>::Ptr& inputCloud,
                           typename pcl::PointCloud<PointT>::Ptr* planeCloud,
                           typename pcl::PointCloud<PointT>::Ptr* nonPlaneCloud,
                           pcl::ModelCoefficients::Ptr* coefficients = NULL);

    /**
     * @brief removeMainPlane given a point cloud looks for the main plane and returns a new point cloud
     *        with the points lying on the main plane removed.
     * @param inputCloud
     * @param cloudMainPlaneRemoved
     * @return
     */
    template <typename PointT>
    bool removeMainPlane(const typename pcl::PointCloud<PointT>::Ptr& inputCloud,
                         typename pcl::PointCloud<PointT>::Ptr& cloudMainPlaneRemoved);

    /**
     * @brief projectToPlane projects the input point cloud in a given plane and returns the resulting
     *        point cloud
     * @param inputCloud
     * @param planeCoefficients
     * @param outputCloud
     */
    template <typename PointT>
    void projectToPlane(const typename pcl::PointCloud<PointT>::Ptr& inputCloud,
                        const pcl::ModelCoefficients::Ptr& planeCoefficients,
                        typename pcl::PointCloud<PointT>::Ptr& outputCloud);

    template <typename PointT>
    void estimateNormals(const typename pcl::PointCloud<PointT>::Ptr& inputCloud,
                         int neighbors,
                         pcl::PointCloud<pcl::Normal>::Ptr* normals);

    /**
     * @brief cylinderSegmentation
     * @param inputCloud
     * @param cylinderCloud
     * @param neighbors number of neighbors considered to estimate the normals
     * @param cylinderCoefficients
     * @return
     */
    template <typename PointT>
    bool cylinderSegmentation(const typename pcl::PointCloud<PointT>::Ptr& inputCloud,
                              typename pcl::PointCloud<PointT>::Ptr& cylinderCloud,
                              int neighbors,
                              double minRadius,
                              double maxRadius,
                              pcl::ModelCoefficients::Ptr& cylinderCoefficients);


    /////////////////////////////////////////////////////////////////////////////////////////////////////////

    template <typename PointT>
    void downSample(const typename pcl::PointCloud<PointT>::Ptr& inputCloud,
                    typename pcl::PointCloud<PointT>::Ptr& outputCloud,
                    double leafSize)
    {
      pcl::VoxelGrid<PointT> vg;
      vg.setInputCloud(inputCloud);
      vg.setLeafSize(leafSize, leafSize, leafSize);
      vg.setDownsampleAllData(true);
      vg.filter(*outputCloud);
    }

    template <typename PointT>
    void passThrough(const typename pcl::PointCloud<PointT>::Ptr& inputCloud,
                     const std::string& axisName,
                     double limitMin,
                     double limitMax,
                     typename pcl::PointCloud<PointT>::Ptr& outputCloud)
    {
      pcl::PassThrough<PointT> pass;
      pass.setInputCloud(inputCloud);
      pass.setFilterFieldName(axisName);
      pass.setFilterLimits(limitMin, limitMax);
      pass.filter(*outputCloud);
    }


    template <typename PointT>
    void minNeighborsInRadiusFilter(const typename pcl::PointCloud<PointT>::Ptr& inputCloud,
                                    double radius,
                                    int minNeighbors,
                                    typename pcl::PointCloud<PointT>::Ptr& outputCloud)
    {
      pcl::RadiusOutlierRemoval<PointT> filter;
      filter.setInputCloud(inputCloud);
      filter.setRadiusSearch(radius);
      filter.setMinNeighborsInRadius(minNeighbors);
      filter.filter(*outputCloud);
    }

    template <typename PointT>
    // pal::statisticalOutlierRemoval를 사용하여 cylinder에 최적화되 inliers points 를 찾는다. 
    // 그들에게서 이웃보다 멀리있는 cloud point 들 즉 outliers 를 필터링하여 제거하는
    void statisticalOutlierRemoval(const typename pcl::PointCloud<PointT>::Ptr& inputCloud,
                                   int numberOfPoints,
                                   double stdDevMult,
                                   typename pcl::PointCloud<PointT>::Ptr& outputCloud)
    {
      pcl::StatisticalOutlierRemoval<PointT> filter;
      filter.setInputCloud(inputCloud);
      // 평균 거리 추정에 사용할 포인트 수 (k)를 설정
      filter.setMeanK(numberOfPoints);
      //Set the standard deviation multiplier threshold. 표준편차 threshold 설정 
      filter.setStddevMulThresh(stdDevMult);
      filter.filter(*outputCloud);
    }

    template <typename PointT>
    void extractIndices(const typename pcl::PointCloud<PointT>::Ptr& inputCloud,
                        const pcl::PointIndices::Ptr& indices,
                        bool setNegative,
                        typename pcl::PointCloud<PointT>::Ptr& filteredCloud)
    {
      pcl::ExtractIndices<PointT> extract;

      extract.setInputCloud(inputCloud);
      extract.setIndices(indices);
      extract.setNegative(setNegative);
      extract.filter(*filteredCloud);
    }

    template <typename PointT>
    bool locateMainPlane(const typename pcl::PointCloud<PointT>::Ptr& inputCloud,
                   pcl::PointIndices::Ptr& inliers,
                   pcl::ModelCoefficients::Ptr& coefficients)
    {
      // Create the segmentation object
      //pcl::SACSegmentation 함수를 이용해서 plan 추출 
      pcl::SACSegmentation<PointT> seg;
      // Optional
      seg.setOptimizeCoefficients (true);
      // Mandatory
      //적용 모델 SACMODEL_PLANE 을 찾는다. 
      seg.setModelType(pcl::SACMODEL_PLANE);
      //적용 방법 RANSAC 방식을 이용한다.   
      seg.setMethodType(pcl::SAC_RANSAC);
      //inlier로 처리할 거리정보 , 
      //RANSAC 에서는 inlier( 모델에서 오차가 허용범위안) , outlier (모델에서 오차가 허용범위 밖 ) 로 구분한다. 
      //statistical trimming 을 통한 outliers 제거 
      seg.setDistanceThreshold(0.02);
      seg.setInputCloud(inputCloud);
      seg.segment(*inliers, *coefficients);

      return !inliers->indices.empty();
    }

    template <typename PointT>
    bool planeSegmentation(const typename pcl::PointCloud<PointT>::Ptr& inputCloud,
                           typename pcl::PointCloud<PointT>::Ptr* planeCloud,
                           typename pcl::PointCloud<PointT>::Ptr* nonPlaneCloud,
                           pcl::ModelCoefficients::Ptr* coefficients)
    {
      pcl::PointIndices::Ptr inliers (new pcl::PointIndices);

      bool planeFound = false;

      if ( coefficients == NULL )
      {
        pcl::ModelCoefficients::Ptr coeff( new pcl::ModelCoefficients() );
        planeFound = locateMainPlane<PointT>(inputCloud, inliers, coeff);
      }
      else
        //RANSAC 을 통해 PLAN model 을 찾아냄. input Cloud data 에서 inliers 에 해당하는 point cloud 를 inliers 에 저장  
        planeFound = locateMainPlane<PointT>(inputCloud, inliers, *coefficients);

      if ( planeFound )
      {
        if ( planeCloud != NULL )
        { 
          // pcl::ExtractIndices 함수를 이용해서 SACSegmentation 로 검출해낸 plan (table) 의 Indices를 가지고 point 들을 축출 
          extractIndices<PointT>(inputCloud,
                                 inliers,
                                 false,       //points in the plane will survive
                                 *planeCloud);
        }
        if ( nonPlaneCloud != NULL )
        { 
          // pcl::ExtractIndices 함수를 이용해서 SACSegmentation 로 검출해낸 plan(table)의 Indices를 가지고 negative 그외의 point 들을 축출 
          extractIndices<PointT>(inputCloud,
                                 inliers,
                                 true,
                                 *nonPlaneCloud);
        }

        return true;
      }
      else
        return false;
    }

    template <typename PointT>
    bool removeMainPlane(const typename pcl::PointCloud<PointT>::Ptr& inputCloud,
                         typename pcl::PointCloud<PointT>::Ptr& cloudMainPlaneRemoved)
    {
      pcl::PointIndices::Ptr inliers (new pcl::PointIndices);
      pcl::ModelCoefficients::Ptr coefficients( new pcl::ModelCoefficients );

      if ( locateMainPlane(inputCloud, inliers, coefficients) )
      {
        extractIndices(inputCloud,
                       inliers,
                       true,        //points not in the plane will survive
                       cloudMainPlaneRemoved);
        return true;
      }
      else
        return false;
    }

    template <typename PointT>
    void projectToPlane(const typename pcl::PointCloud<PointT>::Ptr& inputCloud,
                        const pcl::ModelCoefficients::Ptr& planeCoefficients,
                        typename pcl::PointCloud<PointT>::Ptr& outputCloud)
    {
       // Create the filtering object
       pcl::ProjectInliers<PointT> proj;
       proj.setModelType(pcl::SACMODEL_PLANE);
       proj.setInputCloud(inputCloud);
       proj.setModelCoefficients(planeCoefficients);
       proj.filter(*outputCloud);
    }

    template <typename PointT>
    void estimateNormals(const typename pcl::PointCloud<PointT>::Ptr& inputCloud,
                         int neighbors,
                         pcl::PointCloud<pcl::Normal>::Ptr& normals)
    {
      typename pcl::search::KdTree<PointT>::Ptr tree (new pcl::search::KdTree<PointT> ());
      pcl::NormalEstimation<PointT, pcl::Normal> ne;
      ne.setSearchMethod (tree);
      ne.setInputCloud (inputCloud);
      ne.setKSearch (neighbors);
      ne.compute(*normals);
    }

    template <typename PointT>
    bool cylinderSegmentation(const typename pcl::PointCloud<PointT>::Ptr& inputCloud,
                              typename pcl::PointCloud<PointT>::Ptr& cylinderCloud,
                              int neighbors,
                              double minRadius,
                              double maxRadius,
                              pcl::ModelCoefficients::Ptr& cylinderCoefficients)
    {
      //실린더는 평면보다 축출할게 많다. 
      // normal (법선) 을 저장하기 위한 point cloud 변수 생성  
      pcl::PointCloud<pcl::Normal>::Ptr normals(new pcl::PointCloud<pcl::Normal>);
      // estimateNormals 법선 백터 추정 함수 호출. neighbors value 만큼 이웃한 평면에 수직인 직선을 구함. 
      estimateNormals<PointT>(inputCloud,
                              neighbors,
                              normals);

      if ( normals->size() < 20 )
        return false;
      
      // Normals 법선 기반에서 SACSegmentation 로 실린터 찾아 내기 
      pcl::SACSegmentationFromNormals<PointT, pcl::Normal> seg;
      // 찾아진 실리더 형상의 PointIndices를 담을 inliers 변수 생성 
      pcl::PointIndices::Ptr inliers(new pcl::PointIndices);
      
      // 특성 value true 로 설정  
      seg.setOptimizeCoefficients(true);
      // 찾으려는 모델은 SACMODEL_CYLINDER 형상 
      seg.setModelType(pcl::SACMODEL_CYLINDER);
      // RANSAC 을 사용해서 모델을 찾는다.  
      seg.setMethodType(pcl::SAC_RANSAC);    

      // point normals (점 법선) 과 plane normal ( 평면 법선 ) 사이의 angle 차이 ( 0 ~ pi/2 ) value 를 주기 위한 가중치 
      // 0 ~ 1 사이 value 를 준다.  
      seg.setNormalDistanceWeight (0.1);
      // 포기하기 전에 최대 반복 횟수를 설정하십시오.
      seg.setMaxIterations(10000);

      // inlier로 처리할 거리 정보
      seg.setDistanceThreshold(0.05);
      // 모델을 반지름 측정이 가능하다면 반지름이 minRadius ~  maxRadius 사이에 해당하는 모델만 찾아라 
      seg.setRadiusLimits(minRadius, maxRadius);
      // inputCloud 를 넣어주고  
      seg.setInputCloud(inputCloud);
      // 법선을 넣어 준다.  
      seg.setInputNormals(normals);
      // 실린더의 indices 에 해당하는 inliers, 특성값을 뽑는다.  
      seg.segment(*inliers, *cylinderCoefficients);

      if ( !inliers->indices.empty() )
      {
        //Extract inliers
        // ExtractIndices 함수를 이용하여 cloud point 에서  inliers 의 indices 값을 기반으로 cylinderCloud 를 뽑아낸다.  
        pcl::ExtractIndices<PointT> extract;
        extract.setInputCloud(inputCloud);
        extract.setIndices(inliers);
        extract.setNegative(false);
        extract.filter(*cylinderCloud);
        return true;
      }
      else
        return false;
    }


} //pal
