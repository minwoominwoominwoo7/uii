Changelog
=========

0.4.3 (2016-08-11)
------------------
* upgrades for the new gazebo in kinetic

0.4.0 (2014-08-11)
------------------
* removes email addresses from authors
* adds package for rviz launchers
* Contributors: Marcus Liebhardt

0.3.1 (2013-10-14)
------------------

0.3.0 (2013-08-30)
------------------
* adds bugtracker and repo info to package.xml

0.2.0 (2013-07-11)
------------------
* ROS Hydro beta release.
* Adds catkinized kobuki_qtestsuite

