^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package kobuki_dashboard
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.5.2 (2017-02-23)
------------------
* updated for QtGui -> QtWidgets qt api change in xenial

0.4.0 (2014-08-11)
------------------
* now it uses dataplot class instead of mat dataplot. It still shows weird scaling though..
* removes email addresses from authors
* add robot groups for rqt plugins
* Contributors: Dirk Thomas, Jihoon Lee, Marcus Liebhardt

0.3.1 (2013-10-14)
------------------

0.3.0 (2013-08-30)
------------------
* adds own battery widget to make use of the coloured battery status versions
* adds bugtracker and repo info to package.xml

0.2.0 (2013-07-11)
------------------
* ROS Hydro beta release.
* Adds catkinized kobuki_qtestsuite

