^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package kobuki_dashboard
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.4.2 (2015-03-02)
------------------

0.4.1 (2014-09-19)
------------------

0.4.0 (2014-08-11)
------------------
* removes email addresses from authors
* Contributors: Marcus Liebhardt

0.3.1 (2013-10-14)
------------------
* Rename cmd_vel_mux as yocs_cmd_vel_mux.

0.3.0 (2013-08-30)
------------------
* Add missing install rule for param folder.
* Add random walker app launcher.
* Restructure and updates launchers and worlds.
* Add bugtracker and repo info to package.xml.

0.2.0 (2013-07-11)
------------------
* ROS Hydro beta release.

