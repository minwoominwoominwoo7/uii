
Just run this `update_doxygen.bash` script for autoamated doxygen update.

You will need to provide username and password for repository.
